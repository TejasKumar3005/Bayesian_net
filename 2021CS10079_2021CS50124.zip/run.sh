#/bin/bash
./med.out "$1" "$2"