#/bin/bash
g++ ./medical.cpp -o ./med.out